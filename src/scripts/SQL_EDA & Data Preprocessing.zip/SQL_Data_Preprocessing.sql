use ivf_project;

CREATE TABLE ivf_data_preprocessed AS
SELECT
    patient_name,

    /* AGE */
    CASE
        WHEN TRIM(age) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(age) AS DECIMAL(10,2))
        ELSE NULL
    END AS age,

    /* SPOUSE AGE  */
    CASE
        WHEN TRIM(spouse_age) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(spouse_age) AS DECIMAL(10,2))
        ELSE NULL
    END AS spouse_age,

    indication_description,

    /* CLINICAL PREGNANCY (1, 0, 1(0), N) */
    CASE
        WHEN clinical_pregnancy LIKE '1%' THEN 1
        WHEN clinical_pregnancy = '0' THEN 0
        ELSE NULL
    END AS clinical_pregnancy,

    /* OTHER BINARY OUTCOMES */
    live_birth + 0      AS live_birth,
    neonatal_death + 0  AS neonatal_death,
    twin + 0            AS twin,
    eu + 0              AS eu,
    abortion + 0        AS abortion,

    /* BHCG VALUES */
    CASE
        WHEN TRIM(bhcg_12) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(bhcg_12) AS DECIMAL(12,2))
        ELSE NULL
    END AS bhcg_12,

    CASE
        WHEN TRIM(bhcg_14) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(bhcg_14) AS DECIMAL(12,2))
        ELSE NULL
    END AS bhcg_14,

    CASE
        WHEN TRIM(bhcg_12_14_percent_increase)
             REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(bhcg_12_14_percent_increase) AS DECIMAL(12,2))
        ELSE NULL
    END AS bhcg_12_14_percent_increase,

    /* HORMONES */
    CASE
        WHEN TRIM(fsh) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(fsh) AS DECIMAL(10,2))
        ELSE NULL
    END AS fsh,

    CASE
        WHEN TRIM(amh) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(amh) AS DECIMAL(10,2))
        ELSE NULL
    END AS amh,

    CASE
        WHEN TRIM(e2) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(e2) AS DECIMAL(10,2))
        ELSE NULL
    END AS e2,

    CASE
        WHEN TRIM(progesterone) REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(progesterone) AS DECIMAL(10,2))
        ELSE NULL
    END AS progesterone,

    /* PROCEDURE VARIABLES */
    CASE
        WHEN TRIM(number_of_oocytes) REGEXP '^[0-9]+$'
            THEN CAST(TRIM(number_of_oocytes) AS SIGNED)
        ELSE NULL
    END AS number_of_oocytes,

    CASE
        WHEN TRIM(embryo_transfer_day) REGEXP '^[0-9]+$'
            THEN CAST(TRIM(embryo_transfer_day) AS SIGNED)
        ELSE NULL
    END AS embryo_transfer_day,

    CASE
        WHEN TRIM(number_of_embryos_transferred) REGEXP '^[0-9]+$'
            THEN CAST(TRIM(number_of_embryos_transferred) AS SIGNED)
        ELSE NULL
    END AS number_of_embryos_transferred,

    CASE
        WHEN TRIM(endometrial_thickness)
             REGEXP '^[0-9]+(\\.[0-9]+)?$'
            THEN CAST(TRIM(endometrial_thickness) AS DECIMAL(10,2))
        ELSE NULL
    END AS endometrial_thickness,

    CASE
        WHEN TRIM(ind_number_of_days) REGEXP '^[0-9]+$'
            THEN CAST(TRIM(ind_number_of_days) AS SIGNED)
        ELSE NULL
    END AS ind_number_of_days,

    CASE
        WHEN TRIM(week_of_birth) REGEXP '^[0-9]+$'
            THEN CAST(TRIM(week_of_birth) AS SIGNED)
        ELSE NULL
    END AS week_of_birth

FROM ivf_raw;


# Validation
SELECT COUNT(*) FROM ivf_raw;
SELECT COUNT(*) FROM ivf_data_preprocessed;

SELECT clinical_pregnancy, COUNT(*)
FROM ivf_data_preprocessed
GROUP BY clinical_pregnancy;

# Compare before and after
SELECT
    r.e2 AS raw_e2,
    p.e2 AS clean_e2,
    r.progesterone AS raw_prog,
    p.progesterone AS clean_prog
FROM ivf_raw r
JOIN ivf_data_preprocessed p
USING (patient_name)
LIMIT 10;

SELECT e2 FROM ivf_data_preprocessed
WHERE e2 IN ('N','-','_');


SELECT
    COUNT(*) AS total_rows,
    SUM(age IS NULL) AS age_missing,
    SUM(spouse_age IS NULL) AS spouse_age_missing,
    SUM(e2 IS NULL) AS e2_missing,
    SUM(progesterone IS NULL) AS progesterone_missing,
    SUM(number_of_oocytes IS NULL) AS oocytes_missing
FROM ivf_data_preprocessed;