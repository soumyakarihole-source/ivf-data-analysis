create database IVF_Project;
use IVF_Project;

CREATE TABLE ivf_raw1 (
    patient_name VARCHAR(100),

    age VARCHAR(50),
    spouse_age VARCHAR(50),

    indication_description VARCHAR(255),

    clinical_pregnancy VARCHAR(50),
    live_birth VARCHAR(50),
    neonatal_death VARCHAR(50),
    twin VARCHAR(50),
    eu VARCHAR(50),

    bhcg_12 VARCHAR(50),
    bhcg_14 VARCHAR(50),
    bhcg_12_14_percent_increase VARCHAR(50),

    fsh VARCHAR(50),
    amh VARCHAR(50),
    e2 VARCHAR(50),
    progesterone VARCHAR(50),

    number_of_oocytes VARCHAR(50),
    embryo_transfer_day VARCHAR(50),
    number_of_embryos_transferred VARCHAR(50),
    endometrial_thickness VARCHAR(50),
    ind_number_of_days VARCHAR(50),
    week_of_birth VARCHAR(50),
    abortion VARCHAR(50)
);

##### AGE #####
/* 1st Moment 
/* Mean */
SELECT AVG(CAST(age AS DECIMAL(10,2))) AS mean_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');

/* Median */
SELECT AVG(age_val) AS median_age
FROM (
    SELECT
        CAST(age AS DECIMAL(10,2)) AS age_val,
        ROW_NUMBER() OVER (ORDER BY CAST(age AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE age NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT age AS mode_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','')
GROUP BY age
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(age AS DECIMAL(10,2))) AS variance_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');

/* Std_dev */
SELECT STDDEV(CAST(age AS DECIMAL(10,2))) AS std_dev_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(age AS DECIMAL(10,2))) - MIN(CAST(age AS DECIMAL(10,2))) AS range_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(age AS DECIMAL(10,2))) AS mean_age,
    STDDEV(CAST(age AS DECIMAL(10,2))) AS std_age,
    COUNT(*) AS n
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(age AS DECIMAL(10,2)) - 32.42, 3))
    /
    (755 * POWER(4.75, 3)) AS skewness_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(age AS DECIMAL(10,2)) - 32.42, 4))
        /
        (755 * POWER(4.75, 4))
    ) - 3 AS kurtosis_age
FROM ivf_raw
WHERE age NOT IN ('N','-','_','');


##### SPOUSE_AGE #####
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(spouse_age AS DECIMAL(10,2))) AS mean_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');

/* Median */
SELECT AVG(spouse_age_val) AS median_spouse_age
FROM (
    SELECT
        CAST(spouse_age AS DECIMAL(10,2)) AS spouse_age_val,
        ROW_NUMBER() OVER (ORDER BY CAST(spouse_age AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE spouse_age NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT spouse_age AS mode_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','')
GROUP BY spouse_age
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(spouse_age AS DECIMAL(10,2))) AS variance_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(spouse_age AS DECIMAL(10,2))) AS std_dev_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(spouse_age AS DECIMAL(10,2))) - MIN(CAST(spouse_age AS DECIMAL(10,2))) AS range_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(spouse_age AS DECIMAL(10,2))) AS mean_spouse_age,
    STDDEV(CAST(spouse_age AS DECIMAL(10,2))) AS std_spouse_age,
    COUNT(*) AS n
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');

# use values from above query
# mean, std, n taken from validated summary queries above
SELECT
    SUM(POWER(CAST(spouse_age AS DECIMAL(10,2)) - 35.21, 3))
    /
    (755 * POWER(6.51, 3)) AS skewness_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(spouse_age AS DECIMAL(10,2)) - 35.21, 4))
        /
        (755 * POWER(6.51, 4))
    ) - 3 AS kurtosis_spouse_age
FROM ivf_raw
WHERE spouse_age NOT IN ('N','-','_','');

######## clinical_pregnancy ############
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(clinical_pregnancy AS DECIMAL(10,2))) AS mean_clinical_pregnancy
FROM ivf_raw
WHERE clinical_pregnancy NOT IN ('N','-','_','');


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(clinical_pregnancy AS DECIMAL(10,2))) AS variance_clinical_pregnancy
FROM ivf_raw
WHERE clinical_pregnancy NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(clinical_pregnancy AS DECIMAL(10,2))) AS std_dev_clinical_pregnancy
FROM ivf_raw
WHERE clinical_pregnancy NOT IN ('N','-','_','');


################ live_birth ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(live_birth AS DECIMAL(10,2))) AS mean_live_birth
FROM ivf_raw
WHERE live_birth NOT IN ('N','-','_','');


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(live_birth AS DECIMAL(10,2))) AS variance_live_birth
FROM ivf_raw
WHERE live_birth NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(live_birth AS DECIMAL(10,2))) AS std_dev_live_birth
FROM ivf_raw
WHERE live_birth NOT IN ('N','-','_','');


################ neonatal_death ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(neonatal_death AS DECIMAL(10,2))) AS mean_neonatal_death
FROM ivf_raw
WHERE neonatal_death NOT IN ('N','-','_','');


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(neonatal_death AS DECIMAL(10,2))) AS variance_neonatal_death
FROM ivf_raw
WHERE neonatal_death NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(neonatal_death AS DECIMAL(10,2))) AS std_dev_neonatal_death
FROM ivf_raw
WHERE neonatal_death NOT IN ('N','-','_','');


################ twin ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(twin AS DECIMAL(10,2))) AS mean_twin
FROM ivf_raw
WHERE twin NOT IN ('N','-','_','');


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(twin AS DECIMAL(10,2))) AS variance_twin
FROM ivf_raw
WHERE twin NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(twin AS DECIMAL(10,2))) AS std_dev_twin
FROM ivf_raw
WHERE twin NOT IN ('N','-','_','');


################ eu ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(eu AS DECIMAL(10,2))) AS mean_eu
FROM ivf_raw
WHERE eu NOT IN ('N','-','_','');


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(eu AS DECIMAL(10,2))) AS variance_eu
FROM ivf_raw
WHERE eu NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(eu AS DECIMAL(10,2))) AS std_dev_eu
FROM ivf_raw
WHERE eu NOT IN ('N','-','_','');


################ bhcg_12 ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(bhcg_12 AS DECIMAL(10,2))) AS mean_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');

/* Median */
SELECT AVG(bhcg_12_val) AS median_bhcg_12
FROM (
    SELECT
        CAST(bhcg_12 AS DECIMAL(10,2)) AS bhcg_12_val,
        ROW_NUMBER() OVER (ORDER BY CAST(bhcg_12 AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE bhcg_12 NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT bhcg_12 AS mode_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','')
GROUP BY bhcg_12
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(bhcg_12 AS DECIMAL(10,2))) AS variance_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(bhcg_12 AS DECIMAL(10,2))) AS std_dev_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(bhcg_12 AS DECIMAL(10,2))) - MIN(CAST(bhcg_12 AS DECIMAL(10,2))) AS range_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(bhcg_12 AS DECIMAL(10,2))) AS mean_bhcg_12,
    STDDEV(CAST(bhcg_12 AS DECIMAL(10,2))) AS std_bhcg_12,
    COUNT(*) AS n
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(bhcg_12 AS DECIMAL(10,2)) - 394.837981, 3))
    /
    (753 * POWER(497.9276285617902, 3)) AS skewness_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(bhcg_12 AS DECIMAL(10,2)) - 394.837981, 4))
        /
        (753 * POWER(497.9276285617902, 4))
    ) - 3 AS kurtosis_bhcg_12
FROM ivf_raw
WHERE bhcg_12 NOT IN ('N','-','_','');

################ bhcg_14 ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(bhcg_14 AS DECIMAL(10,2))) AS bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');

/* Median */
SELECT AVG(bhcg_14_val) AS median_bhcg_14
FROM (
    SELECT
        CAST(bhcg_14 AS DECIMAL(10,2)) AS bhcg_14_val,
        ROW_NUMBER() OVER (ORDER BY CAST(bhcg_14 AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE bhcg_14 NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT bhcg_14 AS bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','')
GROUP BY bhcg_14
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(bhcg_14 AS DECIMAL(10,2))) AS variance_bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(bhcg_14 AS DECIMAL(10,2))) AS std_dev_bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(bhcg_14 AS DECIMAL(10,2))) - MIN(CAST(bhcg_14 AS DECIMAL(10,2))) AS range_bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(bhcg_14 AS DECIMAL(10,2))) AS mean_bhcg_14,
    STDDEV(CAST(bhcg_14 AS DECIMAL(10,2))) AS std_bhcg_14,
    COUNT(*) AS n
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(bhcg_14 AS DECIMAL(10,2)) - 1185.617647, 3))
    /
    (510 * POWER(1261.8614746703415, 3)) AS skewness_bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(bhcg_14 AS DECIMAL(10,2)) - 1185.617647, 4))
        /
        (510 * POWER(1261.8614746703415, 4))
    ) - 3 AS kurtosis_bhcg_14
FROM ivf_raw
WHERE bhcg_14 NOT IN ('N','-','_','');

################ bhcg_12_14_percent_increase ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS mean_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');

/* Median */
SELECT AVG(bhcg_12_14_percent_increase_val) AS median_bhcg_12_14_percent_increase
FROM (
    SELECT
        CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2)) AS bhcg_12_14_percent_increase_val,
        ROW_NUMBER() OVER (ORDER BY CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT bhcg_12_14_percent_increase AS mode_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','')
GROUP BY bhcg_12_14_percent_increase
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS variance_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS std_dev_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) - MIN(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS range_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS mean_bhcg_12_14_percent_increase,
    STDDEV(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2))) AS std_bhcg_12_14_percent_increase,
    COUNT(*) AS n
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2)) - 94.089960, 3))
    /
    (755 * POWER(191.95653073285044, 3)) AS skewness_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(bhcg_12_14_percent_increase AS DECIMAL(10,2)) - 94.089960, 4))
        /
        (755 * POWER(191.95653073285044, 4))
    ) - 3 AS kurtosis_bhcg_12_14_percent_increase
FROM ivf_raw
WHERE bhcg_12_14_percent_increase NOT IN ('N','-','_','');

################ fsh ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(fsh AS DECIMAL(10,2))) AS mean_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');

/* Median */
SELECT AVG(fsh_val) AS median_fsh
FROM (
    SELECT
        CAST(fsh AS DECIMAL(10,2)) AS fsh_val,
        ROW_NUMBER() OVER (ORDER BY CAST(fsh AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE fsh NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT fsh AS mode_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','')
GROUP BY fsh
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(fsh AS DECIMAL(10,2))) AS variance_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(fsh AS DECIMAL(10,2))) AS std_dev_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(fsh AS DECIMAL(10,2))) - MIN(CAST(fsh AS DECIMAL(10,2))) AS range_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(fsh AS DECIMAL(10,2))) AS mean_fsh,
    STDDEV(CAST(fsh AS DECIMAL(10,2))) AS std_fsh,
    COUNT(*) AS n
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(fsh AS DECIMAL(10,2)) - 9.665855, 3))
    /
    (415 * POWER(4.024137495353105, 3)) AS skewness_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(fsh AS DECIMAL(10,2)) - 9.665855, 4))
        /
        (415 * POWER(4.024137495353105, 4))
    ) - 3 AS kurtosis_fsh
FROM ivf_raw
WHERE fsh NOT IN ('N','-','_','');

################ amh ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(amh AS DECIMAL(10,2))) AS mean_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');

/* Median */
SELECT AVG(amh_val) AS median_amh
FROM (
    SELECT
        CAST(amh AS DECIMAL(10,2)) AS amh_val,
        ROW_NUMBER() OVER (ORDER BY CAST(amh AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE amh NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT amh AS mode_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','')
GROUP BY amh
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(amh AS DECIMAL(10,2))) AS variance_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(amh AS DECIMAL(10,2))) AS std_dev_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(amh AS DECIMAL(10,2))) - MIN(CAST(amh AS DECIMAL(10,2))) AS range_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(amh AS DECIMAL(10,2))) AS mean_amh,
    STDDEV(CAST(amh AS DECIMAL(10,2))) AS std_amh,
    COUNT(*) AS n
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(amh AS DECIMAL(10,2)) - 0.772614, 3))
    /
    (153 * POWER(0.4284334913674095, 3)) AS skewness_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(amh AS DECIMAL(10,2)) - 0.772614, 4))
        /
        (153 * POWER(0.4284334913674095, 4))
    ) - 3 AS kurtosis_amh
FROM ivf_raw
WHERE amh NOT IN ('N','-','_','');


################ number_of_oocytes ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(number_of_oocytes AS DECIMAL(10,2))) AS mean_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');

/* Median */
SELECT AVG(number_of_oocytes_val) AS median_number_of_oocytes
FROM (
    SELECT
        CAST(number_of_oocytes AS DECIMAL(10,2)) AS number_of_oocytes_val,
        ROW_NUMBER() OVER (ORDER BY CAST(number_of_oocytes AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE number_of_oocytes NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT number_of_oocytes AS mode_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','')
GROUP BY number_of_oocytes
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(number_of_oocytes AS DECIMAL(10,2))) AS variance_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(number_of_oocytes AS DECIMAL(10,2))) AS std_dev_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(number_of_oocytes AS DECIMAL(10,2))) - MIN(CAST(number_of_oocytes AS DECIMAL(10,2))) AS range_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(number_of_oocytes AS DECIMAL(10,2))) AS mean_number_of_oocytes,
    STDDEV(CAST(number_of_oocytes AS DECIMAL(10,2))) AS std_number_of_oocytes,
    COUNT(*) AS n
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(number_of_oocytes AS DECIMAL(10,2)) - 19.167059, 3))
    /
    (425 * POWER(91.9494380090113, 3)) AS skewness_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(number_of_oocytes AS DECIMAL(10,2)) - 19.167059, 4))
        /
        (425 * POWER(91.9494380090113, 4))
    ) - 3 AS kurtosis_number_of_oocytes
FROM ivf_raw
WHERE number_of_oocytes NOT IN ('N','-','_','');

################ embryo_transfer_day ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(embryo_transfer_day AS DECIMAL(10,2))) AS mean_embryo_transfer_day 
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');

/* Median */
SELECT AVG(embryo_transfer_day_val) AS median_embryo_transfer_day
FROM (
    SELECT
        CAST(embryo_transfer_day AS DECIMAL(10,2)) AS embryo_transfer_day_val,
        ROW_NUMBER() OVER (ORDER BY CAST(embryo_transfer_day AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE embryo_transfer_day NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT embryo_transfer_day AS mode_embryo_transfer_day
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','')
GROUP BY embryo_transfer_day
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(embryo_transfer_day AS DECIMAL(10,2))) AS variance_embryo_transfer_day
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(embryo_transfer_day AS DECIMAL(10,2))) AS std_dev_embryo_transfer_day
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(embryo_transfer_day AS DECIMAL(10,2))) - MIN(CAST(embryo_transfer_day AS DECIMAL(10,2))) AS range_embryo_transfer_day
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(embryo_transfer_day AS DECIMAL(10,2))) AS mean_embryo_transfer_day,
    STDDEV(CAST(embryo_transfer_day AS DECIMAL(10,2))) AS std_embryo_transfer_day,
    COUNT(*) AS n
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(embryo_transfer_day AS DECIMAL(10,2)) - 4.114362, 3))
    /
    (752 * POWER(1.1828590125791218, 3)) AS skewness_embryo_transfer_day
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(embryo_transfer_day AS DECIMAL(10,2)) - 4.114362, 4))
        /
        (752 * POWER(1.1828590125791218, 4))
    ) - 3 AS kurtosis_embryo_transfer_day
FROM ivf_raw
WHERE embryo_transfer_day NOT IN ('N','-','_','');

################ number_of_embryos_transferred ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS mean_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');

/* Median */
SELECT AVG(number_of_embryos_transferred_val) AS median_number_of_embryos_transferred
FROM (
    SELECT
        CAST(number_of_embryos_transferred AS DECIMAL(10,2)) AS number_of_embryos_transferred_val,
        ROW_NUMBER() OVER (ORDER BY CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE number_of_embryos_transferred NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT number_of_embryos_transferred AS mode_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','')
GROUP BY number_of_embryos_transferred
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS variance_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS std_dev_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) - MIN(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS range_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS mean_number_of_embryos_transferred,
    STDDEV(CAST(number_of_embryos_transferred AS DECIMAL(10,2))) AS std_number_of_embryos_transferred,
    COUNT(*) AS n
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(number_of_embryos_transferred AS DECIMAL(10,2)) - 1.427126, 3))
    /
    (494 * POWER(0.49466080108986316, 3)) AS skewness_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(number_of_embryos_transferred AS DECIMAL(10,2)) - 1.427126, 4))
        /
        (494 * POWER(0.49466080108986316, 4))
    ) - 3 AS kurtosis_number_of_embryos_transferred
FROM ivf_raw
WHERE number_of_embryos_transferred NOT IN ('N','-','_','');

################ endometrial_thickness ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(endometrial_thickness AS DECIMAL(10,2))) AS mean_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');

/* Median */
SELECT AVG(endometrial_thickness_val) AS median_endometrial_thickness
FROM (
    SELECT
        CAST(endometrial_thickness AS DECIMAL(10,2)) AS endometrial_thickness_val,
        ROW_NUMBER() OVER (ORDER BY CAST(endometrial_thickness AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE endometrial_thickness NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT endometrial_thickness AS mode_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','')
GROUP BY endometrial_thickness
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(endometrial_thickness AS DECIMAL(10,2))) AS variance_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(endometrial_thickness AS DECIMAL(10,2))) AS std_dev_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(endometrial_thickness AS DECIMAL(10,2))) - MIN(CAST(endometrial_thickness AS DECIMAL(10,2))) AS range_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(endometrial_thickness AS DECIMAL(10,2))) AS mean_endometrial_thickness,
    STDDEV(CAST(endometrial_thickness AS DECIMAL(10,2))) AS std_endometrial_thickness,
    COUNT(*) AS n
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(endometrial_thickness AS DECIMAL(10,2)) - 9.758824, 3))
    /
    (731 * POWER(1.9587855293471723, 3)) AS skewness_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(endometrial_thickness AS DECIMAL(10,2)) - 9.758824, 4))
        /
        (731 * POWER(1.9587855293471723, 4))
    ) - 3 AS kurtosis_endometrial_thickness
FROM ivf_raw
WHERE endometrial_thickness NOT IN ('N','-','_','');

################ ind_number_of_days ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(ind_number_of_days AS DECIMAL(10,2))) AS mean_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');

/* Median */
SELECT AVG(ind_number_of_days_val) AS median_ind_number_of_days
FROM (
    SELECT
        CAST(ind_number_of_days AS DECIMAL(10,2)) AS ind_number_of_days_val,
        ROW_NUMBER() OVER (ORDER BY CAST(ind_number_of_days AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE ind_number_of_days NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT ind_number_of_days AS mode_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','')
GROUP BY ind_number_of_days
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(ind_number_of_days AS DECIMAL(10,2))) AS variance_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(ind_number_of_days AS DECIMAL(10,2))) AS std_dev_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(ind_number_of_days AS DECIMAL(10,2))) - MIN(CAST(ind_number_of_days AS DECIMAL(10,2))) AS range_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(ind_number_of_days AS DECIMAL(10,2))) AS mean_ind_number_of_days,
    STDDEV(CAST(ind_number_of_days AS DECIMAL(10,2))) AS std_ind_number_of_days,
    COUNT(*) AS n
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(ind_number_of_days AS DECIMAL(10,2)) - 8.507277, 3))
    /
    (481 * POWER(1.8194059779864735, 3)) AS skewness_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(ind_number_of_days AS DECIMAL(10,2)) - 8.507277, 4))
        /
        (481 * POWER(1.8194059779864735, 4))
    ) - 3 AS kurtosis_ind_number_of_days
FROM ivf_raw
WHERE ind_number_of_days NOT IN ('N','-','_','');

################ week_of_birth ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(week_of_birth AS DECIMAL(10,2))) AS mean_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');

/* Median */
SELECT AVG(week_of_birth_val) AS median_week_of_birth
FROM (
    SELECT
        CAST(week_of_birth AS DECIMAL(10,2)) AS week_of_birth_val,
        ROW_NUMBER() OVER (ORDER BY CAST(week_of_birth AS DECIMAL(10,2))) AS rn,
        COUNT(*) OVER () AS total_rows
    FROM ivf_raw
    WHERE week_of_birth NOT IN ('N','-','_','')
) t
WHERE rn IN (FLOOR((total_rows + 1) / 2), FLOOR((total_rows + 2) / 2));

/* Mode */
SELECT week_of_birth AS mode_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','')
GROUP BY week_of_birth
ORDER BY COUNT(*) DESC
LIMIT 1;


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(week_of_birth AS DECIMAL(10,2))) AS variance_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(week_of_birth AS DECIMAL(10,2))) AS std_dev_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');

/* Range */
SELECT
MAX(CAST(week_of_birth AS DECIMAL(10,2))) - MIN(CAST(week_of_birth AS DECIMAL(10,2))) AS range_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');


/* 3rd Moment */
SELECT
    AVG(CAST(week_of_birth AS DECIMAL(10,2))) AS mean_week_of_birth,
    STDDEV(CAST(week_of_birth AS DECIMAL(10,2))) AS std_week_of_birth,
    COUNT(*) AS n
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');

# use values from above query
SELECT
    SUM(POWER(CAST(week_of_birth AS DECIMAL(10,2)) - 37.425061, 3))
    /
    (407 * POWER(2.8567194693298283, 3)) AS skewness_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');


/* 4th Moment */
SELECT
    (
        SUM(POWER(CAST(week_of_birth AS DECIMAL(10,2)) - 37.425061, 4))
        /
        (407 * POWER(2.8567194693298283, 4))
    ) - 3 AS kurtosis_week_of_birth
FROM ivf_raw
WHERE week_of_birth NOT IN ('N','-','_','');

################ abortion ##################
/* 1st Moment */
/* Mean */
SELECT AVG(CAST(abortion AS DECIMAL(10,2))) AS mean_abortion
FROM ivf_raw
WHERE abortion NOT IN ('N','-','_','');


/* 2nd Moment */
/* Variance */
SELECT VARIANCE(CAST(abortion AS DECIMAL(10,2))) AS variance_abortion
FROM ivf_raw
WHERE abortion NOT IN ('N','-','_','');

/* STD_DEV */
SELECT STDDEV(CAST(abortion AS DECIMAL(10,2))) AS std_dev_abortion
FROM ivf_raw
WHERE abortion NOT IN ('N','-','_','');
